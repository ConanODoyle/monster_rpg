datablock AudioProfile(weaponSwitch2Sound)
{
   filename    = "./sounds/weaponSwitch2.wav";
   description = AudioClose3d;
   preload = true;
};

if($Pref::Server::OldSchoolWeapons::ColorfulColors)
{
	%colors1 = "0.9 0.0 0 0.5";
	%colors2 = "0.9 0.45 0.45 0.25";
}
else
{
	%colors1 = "0.9 0.6 0.6 0.5";
	%colors2 = "0.9 0.75 0.75 0.25";
}

datablock ParticleData(redTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 50;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 100.0;
	spinRandomMin		= -100.0;
	spinRandomMax		= 100.0;
	colors[0]     = %colors1;
	colors[1]     = %colors2;
	colors[2]     = "0.9 0.8 0.8 0.0";
	sizes[0]      = 0.2;
	sizes[1]      = 0.3;
	sizes[2]      = 0.35;
	useInvAlpha = false;
};

datablock ParticleEmitterData(redTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "redTrailParticle";
};


AddDamageType("redRevolvers",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Revolvers> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Revolvers> %1',0.05,1);
datablock ProjectileData(redRevolversProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 45;
   directDamageType    = $DamageType::redRevolvers;
   radiusDamageType    = $DamageType::redRevolvers;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 200;
   verticalImpulse	  = 400;
   explosion           = gunExplosion;
   particleEmitter     = redTrailEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 0.5;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Revovlers A. Bullet";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.9 0.1 0.1 1.000";
else
	%color = "0.450 0.450 0.700 1.000";

datablock ItemData(redRevolversItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/revolver.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Revolvers A.";
	iconName = "./icons/icon_Revolvers";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = redRevolversImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(redRevolversImage)
{
   // Basic Item properties
   shapeFile = "./models/revolver.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = redRevolversProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = redRevolversItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] 			= "Activate";
	stateTransitionOnTimeout[0] 	= "Ready";
	stateTimeoutValue[0] 		= 0.42;
	stateSequence[0] 		= "Activate";
   	stateSound[0]			= weaponSwitch2Sound;

	stateName[1] 			= "Ready";
	stateSequence[1] 		= "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] 			= "Fire";
	stateSequence[2] 		= "Fire";
	stateTransitionOnTimeout[2] 	= "Smoke";
   	stateWaitForTimeout[2] 		= true;
	stateTimeoutValue[2] 		= 0.21;
	stateFire[2] 			= true;
	stateAllowImageChange[2] 	= false;
	stateScript[2] 			= "onFire";
	stateSound[2] 			= gunShot1Sound;
   	stateEmitter[2]					= gunFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   	stateName[3] 			= "Smoke";
	stateEmitter[3]					= gunSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.07;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4] 			= "Reload";
	stateAllowImageChange[4] 	= false;
	stateTransitionOnTriggerUp[4] 	= "FireAkimbo";
	stateSequence[4] 		= "ready";

	stateName[5] 			= "FireAkimbo";
	stateTimeoutValue[5] 		= 0.07;
	stateScript[5] 			= "onFireAkimbo";
	stateTransitionOnTimeOut[5] 	= "Ready";
};

function redRevolversImage::onFireAkimbo(%this,%obj,%slot)
{
   %obj.setImageTrigger(1,1);
}

datablock ShapeBaseImageData(LeftHandedRevolverImage)
{
   // Basic Item properties
   shapeFile = "./models/revolver.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = redRevolversProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = redRevolversItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] 			= "Activate";
	stateTransitionOnTimeout[0] 	= "Ready";
	stateTimeoutValue[0] 		= 0.42;
	stateSequence[0] 		= "Activate";
   	//stateSound[0]			= weaponSwitch2Sound;

	stateName[1] 			= "Ready";
	stateSequence[1] 		= "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] 			= "Fire";
	stateSequence[2] 		= "Fire";
	stateTransitionOnTimeout[2] 	= "Smoke";
   	stateWaitForTimeout[2] 		= true;
	stateTimeoutValue[2] 		= 0.21;
	stateFire[2] 			= true;
	stateAllowImageChange[2] 	= false;
	stateScript[2] 			= "onFire";
	stateSound[2] 			= gunShot1Sound;
   	stateEmitter[2]					= gunFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   	stateName[3] 			= "Smoke";
	stateEmitter[3]					= gunSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.07;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4] 			= "Reload";
	stateAllowImageChange[4] 	= false;
	stateTransitionOnTriggerUp[4] 	= "Ready";
	stateSequence[4] 		= "ready";

};

function LeftHandedRevolverImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2, leftrecoil);

	%projectile = redRevolversProjectile;
	%spread = 0.0002;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}		
}

function redRevolversImage::onMount(%this, %obj, %slot)
{
	Parent::onMount(%this, %obj, %slot);
	%obj.mountImage(LeftHandedRevolverImage, 1);
}

function redRevolversImage::onUnMount(%this, %obj, %slot)
{
	Parent::onUnMount(%this, %obj, %slot);
	%obj.unMountImage(1);
}

function LeftHandedRevolverImage::onMount(%this, %obj, %slot)
{
	Parent::onMount(%this, %obj, %slot);
	%obj.playThread(1, armreadyboth);
}

function LeftHandedRevolverImage::onUnMount(%this, %obj, %slot)
{
	Parent::onUnMount(%this, %obj, %slot);
}

function redRevolversImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2, shiftaway);

	%projectile = redRevolversProjectile;
	%spread = 0.0002;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	
	%obj.setVelocity(VectorAdd(%obj.getVelocity(), VectorScale(%obj.client.player.getEyeVector(),"-1")));
}
