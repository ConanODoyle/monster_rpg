datablock AudioProfile(silencedShot1Sound)
{
   filename    = "./sounds/silencedshot1.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(pistolTrailParticle : sniperTrailParticle)
{
	lifetimeMS           = 2500;
	lifetimeVarianceMS   = 1250;
	colors[0]     = "0.0 0.5 0.25 0.5";
	colors[1]     = "0.25 0.5 0.25 0.25";
	colors[2]     = "0.4 0.5 0.4 0.0";
	sizes[0]      = 0.1;
	sizes[1]      = 0.15;
	sizes[2]      = 0.2;

	useInvAlpha = false;
};

datablock ParticleEmitterData(pistolTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "pistolTrailParticle";
};

AddDamageType("blueTranquilizer",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Tranquilizer> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Tranquilizer> %1',0.2,1);
AddDamageType("blueTranquilizerHeadshot",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Tranquilizer> <bitmap:base/client/ui/ci/skull> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Tranquilizer> <bitmap:base/client/ui/ci/skull> %1',0.2,1);
datablock ProjectileData(blueTranquilizerProjectile)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 30;
   directDamageType    = $DamageType::blueTranquilizer;
   radiusDamageType    = $DamageType::blueTranquilizer;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 200;
   verticalImpulse	  = 400;
   explosion           = gunExplosion;
   particleEmitter     = pistolTrailEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 0.5;

   armingDelay         = 00;
   lifetime            = 10000;
   fadeDelay           = 9500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Tranquilizer Bullet";
};

//////////
// item //
//////////
datablock ItemData(blueTranquilizerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/Silenced_Gun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Tranquilizer";
	iconName = "./icons/icon_Tranquilizer";
	doColorShift = true;
	colorShiftColor = "0.2 0.1 0.8 1.000";

	 // Dynamic properties defined by the scripts
	image = blueTranquilizerImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(blueTranquilizerImage)
{
   // Basic Item properties
   shapeFile = "./models/Silenced_Gun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = blueTranquilizerProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = blueTranquilizerItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.42;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.35;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateEjectShell[2]              = true;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= gunFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= silencedShot1Sound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= gunSmokeEmitter;
	stateEmitterTime[3]				= 0.42;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.42;
	stateTransitionOnTriggerUp[3]     = "Ready";

};

function blueTranquilizerImage::onFire(%this,%obj,%slot)
{
	%projectile = %this.projectile;
	%shellcount = 1;

	%obj.playThread(2, shiftaway);

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	
}

function blueTranquilizerProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 30;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 3;
         %damageType = $DamageType::blueTranquilizerHeadshot;
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}