//audio
datablock AudioProfile(laserCharged1Sound)
{
   filename    = "./sounds/lasercharged.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(laserCharge1Sound)
{
   filename    = "./sounds/lasercharge.wav";
   description = AudioClose3d;
   preload = true;
};

if($Pref::Server::OldSchoolWeapons::ColorfulColors)
{
	%colors1 = "0.9 0.0 0 0.5";
	%colors2 = "0.9 0.45 0.45 0.25";
	%colors3 = "0.9 0.8 0.8 0.0";
}
else
{
	%colors1 = "0 0.9 0.9 0.5";
	%colors2 = "0.45 0.9 0.9 0.25";
	%colors3 = "0.8 0.9 0.9 0.0";
}

datablock ParticleData(redlaserChargeParticle)
{
	dragCoefficient      = 1;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS		= 200;
	lifetimeVarianceMS	= 0;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = %colors1;
	colors[1]     = %colors2;
	colors[2]     = %colors3;
	sizes[0]      = 0.15;
	sizes[1]      = 0.2;
	sizes[2]      = 0.25;
	inheritedVelFactor   = 1;

	useInvAlpha = false;
};

datablock ParticleEmitterData(redlaserChargeEmitter)
{
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.2;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "redlaserChargeParticle";

   ejectionPeriodMS = 12/1.5;
   phiReferenceVel  = 2880*-5*1.5;
};

if($Pref::Server::OldSchoolWeapons::ColorfulColors)
{
	%pcolors1 = "0.9 0.0 0 0.5";
	%pcolors2 = "0.9 0.45 0.45 0.25";
	%pcolors3 = "0.9 0.8 0.8 0.0";
}
else
{
	%pcolors1 = "0 0.9 0.9 0.5";
	%pcolors2 = "0.45 0.9 0.9 0.25";
	%pcolors3 = "0.8 0.9 0.9 0.0";
}

datablock ParticleData(redLaserTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 300;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/thinRing";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = %pcolors1;
	colors[1]     = %pcolors2;
	colors[2]     = %pcolors3;
   sizes[0]      = 0.0;
	sizes[1]      = 0.5;
	sizes[2]      = 0.0;

   times[0] = 0;
   times[1] = 0.3;
   times[2] = 1;

	useInvAlpha = false;
};

datablock ParticleEmitterData(redLaserTrailEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "redLaserTrailParticle";

};

if($Pref::Server::OldSchoolWeapons::ColorfulColors)
{
	%epcolors1 = "0.9 0.0 0 0.5";
	%epcolors2 = "0.9 0.45 0.45 0.25";
	%epcolors3 = "0.9 0.8 0.8 0.0";
}
else
{
	%epcolors1 = "0 0.9 0.9 0.5";
	%epcolors2 = "0.45 0.9 0.9 0.25";
	%epcolors3 = "0.8 0.9 0.9 0.0";
}

datablock ParticleData(redLaserExplosionParticle : horseRayExplosionParticle)
{
	colors[0]     = %epcolors1;
	colors[1]     = %epcolors2;
	colors[2]     = %epcolors3;
};

datablock ParticleEmitterData(redLaserExplosionEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 15;
   velocityVariance = 4.0;
   ejectionOffset   = 1.25;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "redLaserExplosionParticle";
};

datablock ExplosionData(redlaserExplosion : horseRayExplosion)
{
   emitter[0] = redLaserExplosionEmitter; 

   damageRadius = 5;
   radiusDamage = 5;

   impulseRadius = 3;
   impulseForce = 2000;

   playerBurnTime = 500;
};

AddDamageType("redDisintegrator",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_disintegrator> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_disintegrator> %1',0.75,1);
datablock ProjectileData(redDisintegratorProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 100;
   directDamageType    = $DamageType::redDisintegrator;
   radiusDamageType    = $DamageType::redDisintegrator;

   brickExplosionRadius = 0.2;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 15;
   brickExplosionMaxVolume = 20;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1000;
   verticalImpulse     = 500;
   explosion           = redlaserExplosion;
   particleEmitter     = redlaserTrailEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 10000;
   fadeDelay           = 9500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "0.9 0 0";
   
   uiName = "Disintegrator Ray";
};

datablock ProjectileData(redDisintegratorProjectileWeak)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 50;
   directDamageType    = $DamageType::redDisintegrator;
   radiusDamageType    = $DamageType::redDisintegrator;

   brickExplosionRadius = 0.2;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 15;
   brickExplosionMaxVolume = 20;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 500;
   verticalImpulse     = 250;
   explosion           = redlaserExplosion;
   particleEmitter     = redlaserTrailEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 3000;
   fadeDelay           = 2500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "0.9 0 0";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.9 0.1 0.1 1.000";
else
	%color = "0.0 0.7 0.7 1.000";

datablock ItemData(redDisintegratorItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/disintegrator.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Disintegrator";
	iconName = "./icons/icon_disintegrator";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = redDisintegratorImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(redDisintegratorImage)
{
   // Basic Item properties
   shapeFile = "./models/disintegrator.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = redDisintegratorItem;
   ammo = " ";
   projectile = redDisintegratorProjectile;
   projectileType = Projectile;

   casing = gunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 1000;

   doColorShift = true;
   colorShiftColor = redDisintegratorItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.56;
	stateSequence[0]		= "Reload";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "PreCharge";
	stateAllowImageChange[1]        = true;

	stateName[2]                    	= "PreCharge";
	stateTransitionOnTimeout[2]		= "Charge";
	stateTimeoutValue[2]            	= 0.14;
	stateWaitForTimeout[2]			= false;
	stateTransitionOnTriggerUp[2]		= "FireA";
	stateAllowImageChange[2]        	= false;


	stateName[3]                     	= "Armed";
	stateTransitionOnTriggerUp[3]    	= "FireB";
	stateTransitionOnTimeout[3]		= "Armed";
	stateTimeoutValue[3]            	= 0.14;
	stateScript[3]                  	= "onArmed";
	stateEmitter[3]                 	= redlaserChargeEmitter;
	stateEmitterTime[3]             	= 0.14;
	stateSequence[3]		        = "PreFire";
	stateEmitterNode[3]             	= "muzzleNode";
	stateWaitForTimeout[3]			= false;
	stateAllowImageChange[3]         	= false;
	stateSound[3]			  	= laserCharged1Sound;

	stateName[4]                    = "FireA";
	stateTransitionOnTimeout[4]   = "Reload";
	stateTimeoutValue[4]            = 0.07;
	stateFire[4]                    = true;
	stateSequence[4]		= "Fire";
	stateAllowImageChange[4]        = false;
	stateEmitter[4]			  = gunFlashEmitter;
	stateEmitterTime[4]		  = 0.07;
	stateEmitterNode[4]		  = "muzzleNode";
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		  = true;
	stateSound[4]			  = printFireSound;

	stateName[5]                    	= "FireB";
	stateTransitionOnTimeout[5]     	= "Reload";
	stateTimeoutValue[5]            	= 0.07;
	stateFire[5]                    	= true;
	stateSequence[5]		        = "Fire";
	stateAllowImageChange[5]        	= false;
	stateEmitter[5]			  = gunFlashEmitter;
	stateEmitterTime[5]		  = 0.07;
	stateEmitterNode[5]		  = "muzzleNode";
	stateScript[5]                  	= "onFireB";
	stateWaitForTimeout[5]		  	= true;
	stateSound[5]			  	= printFireSound;

	stateName[6]                    = "Reload";
	stateTimeoutValue[6]            = 0.56;
	stateSequence[6]		= "Reload";
	stateTransitionOnTimeout[6]     = "Ready";
	stateEmitter[6]			  = gunSmokeEmitter;
	stateEmitterTime[6]		  = 1;
	stateEmitterNode[6]		  = "muzzleNode";

	stateName[7]                    	= "Charge";
	stateTransitionOnTimeout[7]		= "Armed";
	stateTimeoutValue[7]            	= 0.96;
	stateWaitForTimeout[7]			= false;
	stateTransitionOnTriggerUp[7]		= "FireA";
	stateAllowImageChange[7]        	= false;
	stateSound[7]			     	= laserCharge1Sound;
};

function redDisintegratorImage::onArmed(%this,%obj,%slot)
{
	%obj.client.centerPrint("\c3MAX CHARGE", 0.3);
}

function redDisintegratorImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2, shiftaway);
	%projectile = redDisintegratorProjectileWeak;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}

function redDisintegratorImage::onFireB(%this,%obj,%slot)
{
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;

	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-4")));

	%obj.playThread(2, shiftaway);
	%projectile = redDisintegratorProjectile;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}