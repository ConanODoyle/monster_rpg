datablock ProjectileData(greenMortarProjectile)
{
   projectileShapeName = "add-ons/Vehicle_Pirate_Cannon/CannonBall.dts";
   directDamage        = 100;
   directDamageType    = $DamageType::CannonBallDirect;
   radiusDamageType    = $DamageType::CannonBallRadius;

   brickExplosionRadius = 5;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 50;
   brickExplosionMaxVolume = 60;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 120;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1000;
   verticalImpulse     = 1000;
   explosion           = gravityRocketExplosion;
   particleEmitter     = cannonBallTrailEmitter;
   explodeOnDeath        = true;

   sound = WhistleLoopSound;

   muzzleVelocity      = 100;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 20000;
   fadeDelay           = 19500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.2;
   isBallistic         = true;
   gravityMod = 1;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   
   uiName = "Mortar Ball";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.1 0.5 0.25 1.000";
else
	%color = "0.100 0.300 0.300 1.000";

datablock ItemData(greenMortarItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/Mortar.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Mortar";
	iconName = "./icons/icon_Mortar";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = greenMortarImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 0;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(greenMortarImage)
{
   // Basic Item properties
   shapeFile = "./models/Mortar.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0 1 -2"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = greenMortarItem;
   ammo = " ";
   projectile = greenMortarProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 1000;

   doColorShift = true;
   colorShiftColor = greenMortarItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]      = "Reload";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;

	stateName[2]                    = "Fire";
	stateTransitionOnTriggerUp[2]   = "LoadCheckA";
	stateTimeoutValue[2]            = 0.28;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;
	stateEmitter[2]			  = gunSmokeEmitter;
	stateEmitterTime[2]		  = 0.05;
	stateEmitterNode[2]		  = "muzzleNode";
	stateSound[2]			  = TankshotSound;

	stateName[3]				= "LoadCheckA";
	stateScript[3]				= "onLoadCheck";
	stateTimeoutValue[3]			= 0.01;
	stateTransitionOnTimeout[3]		= "LoadCheckB";
	
	stateName[4]				= "LoadCheckB";
	stateTransitionOnAmmo[4]		= "Ready";
	stateTransitionOnNoAmmo[4]		= "Reload";

	stateName[5]				= "Reload";
	stateTimeoutValue[5]			= 1.5;
	stateScript[5]				= "onReloadStart";
	stateTransitionOnTimeout[5]		= "Reloaded";
	stateEmitter[5]			  = gunSmokeEmitter;
	stateEmitterTime[5]		  = 1.5;
	stateEmitterNode[5]		  = "muzzleNode";
	stateWaitForTimeout[5]			= true;
	
	stateName[6]				= "FireLoadCheckA";
	stateScript[6]				= "onLoadCheck";
	stateTimeoutValue[6]			= 0.01;
	stateTransitionOnTimeout[6]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadSmoke";
	
	stateName[10] 				= "ReloadSmoke";
	stateEmitter[10]			= gunSmokeEmitter;
	stateEmitterTime[10]			= 0.35;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.14;
	stateTransitionOnTimeout[10]		= "Reload";
	
	stateName[11]				= "Reloaded";
	stateTimeoutValue[11]			= 0.14;
	stateScript[11]				= "onReloaded";
	stateTransitionOnTimeout[11]		= "Ready";
};

function greenMortarImage::onFire(%this,%obj,%slot)
{
	%obj.toolAmmo[%obj.currTool]--;
	%dist = 100;
	%range = 300*getWord(%obj.getScale(),2);
	%start = %obj.getEyePoint();
	%fvec = %obj.getForwardVector();
	%fX = getWord(%fvec,0);
	%fY = getWord(%fvec,1);
	%evec = %obj.getEyeVector();
	%eX = getWord(%evec,0);
	%eY = getWord(%evec,1);
	%eZ = getWord(%evec,2);
	%eXY = mSqrt(%eX*%eX+%eY*%eY);
	%aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%end = vectorAdd(%start,vectorScale(%aimVec,%range));
	%ray = containerRayCast(%start,%end,$TypeMasks::All,%obj);
	%target = firstWord(%ray);
	if(isObject(%target))
	{
		%pos = posFromRaycast(%ray);
		%dist = vectorDist(%obj.getPosition(),%pos);
	}
	%initVelocity = vectorScale(%obj.getMuzzleVector(%slot),18.25);
	%initVelocity = vectorAdd(%initVelocity,getRandom(0,3) / 6 SPC getRandom(0,3) / 6 SPC %dist/3.75);
	%p = new (%this.projectileType)()
	{
		dataBlock = %this.projectile;
		initialVelocity = %initVelocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	%obj.lastMortarFire = getSimTime();
	return %p;
}

function greenMortarImage::onReloadStart(%this,%obj,%slot)
{
	%obj.toolAmmo[%obj.currTool] = 0;
}

function greenMortarImage::onReloaded(%this,%obj,%slot)
{
	%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
	%obj.setImageAmmo(%slot,1);
}

function greenMortarImage::onMount(%this,%obj,%slot)
{
	Parent::onMount(%this, %obj, %slot);
	%obj.playThread(0, armreadyboth);
}

function greenMortarImage::onUnMount(%this,%obj,%slot)
{
	Parent::onUnMount(%this,%obj,%slot);	
	%obj.playThread(0, root);
}