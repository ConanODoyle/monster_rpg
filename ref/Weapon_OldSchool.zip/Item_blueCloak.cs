datablock ItemData(blueCloakItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "base/data/shapes/brickweapon.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "Spy Kit";
	iconName = "./icons/icon_blueCloak";
	doColorShift = true;
	colorShiftColor = "0.2 0.1 0.8 1.000";

	image = blueCloakImage;
	canDrop = true;
};

datablock ShapeBaseImageData(blueCloakImage)
{
   shapeFile = "base/data/shapes/brickweapon.dts";
   emap = true;

   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0;
   rotation = eulerToMatrix("0 0 0");

   className = "WeaponImage";
   item = blueCloakItem;

   armReady = true;

   doColorShift = true;
   colorShiftColor = blueCloakItem.colorShiftColor;

	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;

	stateName[2]                     = "Fire";
	stateTransitionOnTimeout[2]      = "Ready";
	stateAllowImageChange[2]         = true;
	stateScript[2]                   = "onFire";
	stateTimeoutValue[2]		 = 1;
};

function blueCloakImage::onFire(%this, %obj, %slot)
{
	%data = %obj.getDatablock();
	%model = fileName(%data.shapeFile);
	if(%model !$= "m.dts")
	{
		if($Pref::Server::OldSchoolWeapons::UnlimitedSpyKit)
		{
			//i dont like doing this which is why i put it behind a pref, but we're going to set the best default playertype we can for what the player is.
			//the problem with this is this will change horses/other custom model playertypes into blockheads.
			//they also might have disabled some default playertypes.
			if(%data.canJet)
			{
				if(%data.jetEnergyDrain < 2)
					%obj.changeDatablock(PlayerStandardArmor);
				else if(%data.jetEnergyDrain < 5)
					%obj.changeDatablock(PlayerFuelJet);
				else if(%data.jetEnergyDrain < 10)
					%obj.changeDatablock(PlayerLeapJet);
				else
					%obj.changeDatablock(PlayerJumpJet);
			}
			else
				%obj.changeDatablock(PlayerNoJet);
		}
		else
		{
			%obj.client.centerPrint("\c2You cannot use the spy kit as a " @ %data.uiName @ ".", 2);
			return;
		}
	}
	%obj.canCloak = true;
	%s = %obj.currTool;
	%obj.tool[ %s ] = 0;
    %obj.weaponCount--;
	%obj.client.centerPrint("\c2Crouch to go invisible!", 2);
    messageClient(%obj.client, 'MsgItemPickup', '', %s , 0);
    serverCmdUnUseTool(%obj.client);
}

package blueCloakingPlayer
{
	function Armor::onTrigger(%this, %obj, %slot, %val)
	{
		parent::onTrigger(%this, %obj, %slot, %val);
		if(%slot == 3)
		{
			if(%obj.canCloak)
			{
				if(%val == 1)
					%obj.Cloak(1);
				else
					%obj.Cloak(0);
			}
		}
	}
};
activatePackage(blueCloakingPlayer);

function Player::Cloak(%this, %val)
{
	%data = %this.getDatablock();
	%model = fileName(%data.shapeFile);
	if(%model !$= "m.dts")
	{
		%this.canCloak = false;
		return;
	}
	
	if(%val == 1)
	{
		cancel(%this.applyBodyPartsSchedule);
		cancel(%this.unHideNameSchedule);
		%this.colorSchedule = %this.schedule(20, setNodeColor, "ALL", "1 1 1 0.5");
		%this.hideNodeSchedule = %this.schedule(400, hideNode, "ALL");
		%this.hideNameSchedule = %this.schedule(400, setShapeNameDistance, 0);
		%this.Cloaking = true;
	}
	else
	{
		cancel(%this.colorSchedule);
		cancel(%this.hideNodeSchedule);
		cancel(%this.hideNameSchedule);
		%this.client.applyBodyParts();
		%this.setNodeColor("ALL", "1 1 1 0.5");
		%this.applyBodyPartsSchedule = %this.client.schedule(200, applyBodyColors);
		%this.unHideNameSchedule = %this.schedule(200, setShapeNameDistance, 40);
		%this.unHideNode("headSkin");
		%this.Cloaking = false;
	}
}