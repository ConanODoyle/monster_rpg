%error = ForceRequiredAddOn("Weapon_Gun");
%error1 = ForceRequiredAddOn("Weapon_Bow");
%error2 = ForceRequiredAddOn("Weapon_Rocket_Launcher");
%error3 = ForceRequiredAddOn("Weapon_Sword");
%error4 = ForceRequiredAddOn("Vehicle_Tank");
%error5 = ForceRequiredAddOn("Particle_Basic");
%error6 = ForceRequiredAddOn("Weapon_Horse_Ray");
%error7 = ForceRequiredAddOn("Projectile_GravityRocket");
%error8 = ForceRequiredAddOn("Vehicle_Pirate_Cannon");
%error9 = ForceRequiredAddOn("Weapon_Push_Broom");

if(%error == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Weapon_Gun not found");
   %missingAddon = true;
}
if(%error1 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Weapon_Bow not found");
   %missingAddon = true;
}
if(%error2 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Weapon_Rocket_Launcher not found");
   %missingAddon = true;
}
if(%error3 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Weapon_Sword not found");
   %missingAddon = true;
}
if(%error4 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Vehicle_Tank not found");
   %missingAddon = true;
}
if(%error5 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Particle_Basic not found");
   %missingAddon = true;
}
if(%error6 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Weapon_Horse_Ray not found");
   %missingAddon = true;
}
if(%error7 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Projectile_GravityRocket not found");
   %missingAddon = true;
}
if(%error8 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Vehicle_Pirate_Cannon not found");
   %missingAddon = true;
}
if(%error9 == $Error::AddOn_Disabled)
{
   error("ERROR: Weapon_OldSchool - required add-on Weapon_Push_Broom not found");
   %missingAddon = true;
}

if(%missingAddon)
	return;

if($Pref::Server::OldSchoolWeapons::ColorfulColors $= "")
	$Pref::Server::OldSchoolWeapons::ColorfulColors = false;
if($Pref::Server::OldSchoolWeapons::UnlimitedSpyKit $= "")
	$Pref::Server::OldSchoolWeapons::UnlimitedSpyKit = false;

//RTB Prefs
if($RTB::Hooks::ServerControl)
{
	RTB_registerPref("Restore colorful style (requires restart)",	"Old School Weaponset",	"$Pref::Server::OldSchoolWeapons::ColorfulColors",	"bool",	"Weapon_OldSchool",	false,	true,	false,	false);
	RTB_registerPref("Spy kit is usable with any player shape",		"Old School Weaponset",	"$Pref::Server::OldSchoolWeapons::UnlimitedSpyKit",	"bool",	"Weapon_OldSchool",	false,	false,	false,	false);
}

exec("./Support_AmmoGuns.cs");
exec("./Item_blueCloak.cs"); //restored
exec("./Weapon_redBaseballBat.cs");
exec("./Weapon_blueLongbow.cs");
exec("./Weapon_blueSniper.cs");
exec("./Weapon_blueTranquilizer.cs");
exec("./Weapon_greenCrossbow.cs");
exec("./Weapon_greenGLauncher.cs");
exec("./Weapon_greenGLaunchers.cs"); //added
exec("./Weapon_greenMortar.cs");
exec("./Weapon_orangeFlamethrower.cs");
exec("./Weapon_redDisintegrator.cs");
exec("./Weapon_redMachineGun.cs");
exec("./Weapon_redRevolvers.cs");
exec("./Weapon_redRevolver.cs"); //added
exec("./Weapon_redShotgun.cs");