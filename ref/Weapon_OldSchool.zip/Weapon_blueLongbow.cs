datablock AudioProfile(Block_PlantBrick_Sound)
{
   filename = "base/data/sound/clickPlant.wav";
   description = AudioClosest3d;
   preload = false;
};

AddDamageType("blueLongbow",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_longbowArrow> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_longbowArrow> %1',0.75,1);
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%projectile = "./models/blueArrow.dts";
else
	%projectile = "./models/normArrow.dts";

datablock ProjectileData(blueLongbowProjectile)
{
   projectileShapeName = %projectile;
   directDamage        = 20;
   directDamageType    = $DamageType::blueLongbow;
   radiusDamageType    = $DamageType::blueLongbow;

   explosion             = arrowExplosion;
   stickExplosion        = arrowStickExplosion;
   bloodExplosion        = arrowStickExplosion;
   particleEmitter       = arrowTrailEmitter;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = true;  

   armingDelay         = 20000;
   lifetime            = 20000;
   fadeDelay           = 19500;

   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.25;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   muzzleVelocity      = 125;
   velInheritFactor    = 0;

   uiName = "Longbow Arrow";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.2 0.1 0.8 1.000";
else
	%color = "0.900 0.800 0.600 1.000";
	
datablock ItemData(blueLongbowItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/longbow.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Longbow";
	iconName = "./icons/icon_longbow";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = blueLongbowImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(blueLongbowImage)
{
   // Basic Item properties
   shapeFile = "./models/longbow.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 10" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = blueLongbowProjectile;
   projectileType = Projectile;

	casing = GunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = blueLongbowItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.56;
	stateSequence[0]		= "Reload";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Charge";
	stateAllowImageChange[1]        = true;

	stateName[2]                    	= "Charge";
	stateTransitionOnTimeout[2]		= "PreArmed";
	stateTimeoutValue[2]            	= 0.28;
	stateWaitForTimeout[2]			= false;
	stateSequence[2]		        = "Charge";
	stateTransitionOnTriggerUp[2]		= "FireA";
	stateAllowImageChange[2]        	= false;

	stateName[3]                     	= "Armed";
	stateTransitionOnTriggerUp[3]    	= "FireB";
	stateTimeoutValue[3]            	= 0.42;
	stateWaitForTimeout[3]			= false;
	stateScript[3]                         = "onArmed";
	stateAllowImageChange[3]         	= false;
	stateSound[3]			  	= Block_PlantBrick_Sound;

	stateName[4]                    = "FireA";
	stateTransitionOnTimeout[4]   = "Reload";
	stateTimeoutValue[4]            = 0.07;
	stateFire[4]                    = true;
	stateSequence[4]		= "Fire";
	stateAllowImageChange[4]        = false;
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		  = true;
	stateSound[4]			  = bowFireSound;

	stateName[5]                    	= "FireB";
	stateTransitionOnTimeout[5]     	= "Reload";
	stateTimeoutValue[5]            	= 0.07;
	stateFire[5]                    	= true;
	stateSequence[5]		        = "Fire";
	stateAllowImageChange[5]        	= false;
	stateScript[5]                  	= "onFireB";
	stateWaitForTimeout[5]		  	= true;
	stateSound[5]			  	= bowFireSound;

	stateName[6]                    = "Reload";
	stateTimeoutValue[6]            = 0.56;
	stateSequence[6]		= "Reload";
	stateTransitionOnTimeout[6]     = "Ready";

	stateName[7]                    	= "PreArmed";
	stateTransitionOnTimeout[7]		= "Armed";
	stateTimeoutValue[7]            	= 0.7;
	stateWaitForTimeout[7]			= false;
	stateTransitionOnTriggerUp[7]		= "FireA";
	stateAllowImageChange[7]        	= false;
};

function blueLongbowImage::onArmed(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
}

function blueLongbowImage::onFire(%this,%obj,%slot)
{
	%projectile = %this.projectile;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			scale = "1.25 1.25 1.25";
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}

function blueLongbowImage::onFireB(%this,%obj,%slot)
{
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;

	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-4")));

	%obj.playThread(2, shiftaway);
	%projectile = %this.projectile;
	%spread = 0.003;
	%shellcount = 4;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			scale = "1.25 1.25 1.25";
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}