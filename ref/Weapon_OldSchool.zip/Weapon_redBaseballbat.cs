datablock ExplosionData(mainMeleeExplosion : hammerExplosion)
{
   soundProfile = HammerHitSound;
};

AddDamageType("redBaseballBat",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Baseballbat> <bitmap:base/client/ui/ci/star> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Baseballbat> <bitmap:base/client/ui/ci/star> %1',0.75,1);
AddDamageType("redBaseballBatWeak",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Baseballbat> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Baseballbat> %1',0.75,1);
datablock ProjectileData(redBaseballBatProjectile)
{
   directDamage        = 5000;
   directDamageType  = $DamageType::redBaseballBat;
   radiusDamageType  = $DamageType::redBaseballBat;
   explosion           = mainMeleeExplosion;
   impactImpulse	   = 5000;
   verticalImpulse	   = 5000;
   //particleEmitter     = as;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   
   uiName = "Baseball Bat Charged";
};
datablock ProjectileData(redBaseballBatWeakProjectile)
{
   directDamage        = 30;
   directDamageType  = $DamageType::redBaseballBatWeak;
   radiusDamageType  = $DamageType::redBaseballBatWeak;
   explosion           = mainMeleeExplosion;
   impactImpulse	   = 50;
   verticalImpulse	   = 50;
   //particleEmitter     = as;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   
   uiName = "Baseball Bat";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.9 0.1 0.1 1.000";
else
	%color = "0.400 0.196 0 1.000";

datablock ItemData(redBaseballBatItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/Baseball_Bat.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Baseball Bat";
	iconName = "./icons/icon_BaseballBat";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = redBaseballBatImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(redBaseballBatImage)
{
   // Basic Item properties
   shapeFile = "./models/Baseball_Bat.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   //eyeOffset = "0.7 1.2 -0.25";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = redBaseballBatItem;
   ammo = " ";
   projectile = redBaseballBatProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = redBaseballBatItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]	= true;
	
	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.56;
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]	= "AbortCharge";
	stateScript[2]                  = "onCharge";
	stateAllowImageChange[2]        = false;
	
	stateName[3]			= "AbortCharge";
	stateTransitionOnTimeout[3]	= "Ready";
	stateTimeoutValue[3]		= 0.28;
	stateWaitForTimeout[3]		= true;
	stateScript[3]			= "onAbortCharge";
	stateAllowImageChange[3]	= false;

	stateName[4]			= "Armed";
	stateTransitionOnTimeout[4]	= "Armed";
	stateTimeoutValue[4]            = 0.2;
	stateTransitionOnTriggerUp[4]	= "Fire";
	stateScript[4]                  = "onArmed";
	stateSound[4]			= pushBroomSwingSound;
	stateAllowImageChange[4]	= false;

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.56;
	stateFire[5]			= true;
	stateSequence[5]		= "fire";
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;

};

function redBaseballBatImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, SpearReady);
}

function redBaseballBatImage::onArmed(%this, %obj, %slot)
{
	%obj.playthread(3, RotCW);
}

function redBaseballBatImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playthread(2, root);
	%projectile = redBaseballBatWeakProjectile;
	%spread = 0.00001;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getEyePoint();
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function redBaseballBatImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, SpearThrow);
	Parent::onFire(%this, %obj, %slot);
}

function redBaseballBatProjectile::damage(%this, %obj, %col, %player)
{
   if(%this.directDamage <= 0)
      return;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
	%obj.spawnExplosion(winStarProjectile,getWord(%col.getScale(),2)*1);
   }
   parent::damage(%this,%obj,%col,%fade,%pos,%normal);
}
	
