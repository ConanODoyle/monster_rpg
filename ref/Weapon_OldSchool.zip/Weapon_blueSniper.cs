//audio
datablock AudioProfile(gunReload1Sound)
{
   filename    = "./sounds/gunReload1.wav";
   description = AudioClose3d;
   preload = true;
};

if($Pref::Server::OldSchoolWeapons::ColorfulColors)
{
	%colors1 = "0.2 0.0 0.8 0.5";
	%colors2 = "0.4 0.4 0.8 0.25";
}
else
{
	%colors1 = "0.7 0.6 0.8 0.5";
	%colors2 = "0.7 0.7 0.8 0.25";
}

datablock ParticleData(sniperTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 2500;
	lifetimeVarianceMS   = 1250;
	textureName          = "base/data/particles/thinRing";
	spinSpeed		= 1000.0;
	spinRandomMin		= -1000.0;
	spinRandomMax		= 1000.0;
	colors[0]     = %colors1;
	colors[1]     = %colors2;
	colors[2]     = "0.7 0.7 0.8 0.0";
	sizes[0]      = 0.2;
	sizes[1]      = 0.275;
	sizes[2]      = 0.3;

	useInvAlpha = false;
};

datablock ParticleEmitterData(sniperTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "sniperTrailParticle";
};

AddDamageType("blueSniper",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Sniper> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Sniper> %1',0.75,1);
datablock ProjectileData(blueSniperProjectile)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 175;
   directDamageType    = $DamageType::blueSniper;
   radiusDamageType    = $DamageType::blueSniper;

   brickExplosionRadius = 0.2;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 15;
   brickExplosionMaxVolume = 20;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1000;
   verticalImpulse     = 500;
   explosion           = gunExplosion;
   particleEmitter     = sniperTrailEmitter;

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 20000;
   fadeDelay           = 19500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   
   uiName = "Sniper Bullet ";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.2 0.1 0.8 1.000";
else
	%color = "0.25 0.25 0.25 1.000";

datablock ItemData(blueSniperItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/Sniper_Rifle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Sniper Rifle";
	iconName = "./icons/icon_Sniper";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = blueSniperImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 0;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(blueSniperImage)
{
   // Basic Item properties
   shapeFile = "./models/Sniper_Rifle.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = blueSniperItem;
   ammo = " ";
   projectile = blueSniperProjectile;
   projectileType = Projectile;

   casing = gunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 1000;

   doColorShift = true;
   colorShiftColor = blueSniperItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]      = "Reload";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]	        = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.42;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;
	stateEmitter[2]			  = gunFlashEmitter;
	stateEmitterTime[2]		  = 0.05;
	stateEmitterNode[2]		  = "muzzleNode";
	stateSound[2]			  = gunShot1Sound;

	stateName[3] 			  = "Smoke";
	stateEmitter[3]			  = gunSmokeEmitter;
	stateEmitterTime[3]		  = 1;
	stateEmitterNode[3]		  = "muzzleNode";
	stateTimeoutValue[3]            = 0.07;
	stateTransitionOnTimeout[3]     = "LoadCheckA";

	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 0.56;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Reloaded";
	stateWaitForTimeout[6]			= true;
	stateEjectShell[6]                      = true;
	stateSequence[6]	                = "reload";
	stateSound[6]				= gunReload1Sound;
	
	stateName[7]				= "FireLoadCheckA";
	stateScript[7]				= "onLoadCheck";
	stateTimeoutValue[7]			= 0.01;
	stateTransitionOnTimeout[7]		= "FireLoadCheckB";
	
	stateName[8]				= "FireLoadCheckB";
	stateTransitionOnAmmo[8]		= "Ready";
	stateTransitionOnNoAmmo[8]		= "ReloadSmoke";
	
	stateName[9] 				= "ReloadSmoke";
	stateEmitter[9]			        = gunSmokeEmitter;
	stateEmitterTime[9]			= 0.42;
	stateEmitterNode[9]			= "muzzleNode";
	stateTimeoutValue[9]			= 0.14;
	stateTransitionOnTimeout[9]		= "Reload";
	
	stateName[10]				= "Reloaded";
	stateTimeoutValue[10]			= 0.07;
	stateScript[10]				= "onReloaded";
	stateTransitionOnTimeout[10]		= "TriggerUp";

	stateName[11]                    = "TriggerUp";
	stateTransitionOnTriggerUp[11]   = "Ready";
};

function blueSniperImage::onFire(%this,%obj,%slot)
{
	if((%obj.lastFireTime + %this.minShotTime) > getSimTime())
		return;
	
	%obj.playThread(2, shiftaway);
	%obj.toolAmmo[%obj.currTool]--;

	%projectile = %this.projectile;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			scale = "1.75 1.75 1.75";
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	
	%obj.lastFireTime = getSimTime();
	%obj.setVelocity(VectorAdd(%obj.getVelocity(), VectorScale(%obj.client.player.getEyeVector(),"-2")));
}

function blueSniperImage::onReloadStart(%this,%obj,%slot)
{
	%obj.toolAmmo[%obj.currTool] = 0;
}

function blueSniperImage::onReloaded(%this,%obj,%slot)
{
	%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
	%obj.setImageAmmo(%slot,1);
}