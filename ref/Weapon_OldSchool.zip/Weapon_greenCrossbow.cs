datablock ExplosionData(greenboltExplosion : tankExplosion)
{
   impulseRadius = 5;
   impulseForce = 1000;
};

AddDamageType("greenCrossbow",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Bolt> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Bolt> %1',0.75,1);
datablock ProjectileData(greenCrossbowProjectile)
{
   projectileShapeName = "./models/Bolt.dts";
   directDamage        = 35;
   directDamageType    = $DamageType::greenCrossbow;
   radiusDamageType    = $DamageType::greenCrossbow;

   brickExplosionRadius = 5;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 50;
   brickExplosionMaxVolume = 60;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 120;  //max volume of bricks that we can destroy if they aren't connected to the ground

   explosion           = arrowStickExplosion;
   stickExplosion        = arrowStickExplosion;
   bloodExplosion        = greenboltExplosion;
   particleEmitter       = arrowTrailEmitter;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;
   impactImpulse	     = 500;
   verticalImpulse     = 1000;  

   armingDelay         = 20000;
   lifetime            = 20000;
   fadeDelay           = 19500;

   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.25;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   muzzleVelocity      = 100;
   velInheritFactor    = 0;

   uiName = "Crossbow Bolt";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.1 0.5 0.25 1.000";
else
	%color = "0.25 0.25 0.25 1.000";

datablock ItemData(greenCrossbowItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/Crossbow.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Crossbow";
	iconName = "./icons/icon_Crossbow";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = greenCrossbowImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(greenCrossbowImage)
{
   // Basic Item properties
   shapeFile = "./models/Crossbow.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = greenCrossbowItem;
   ammo = " ";
   projectile = greenCrossbowProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 1000;

   doColorShift = true;
   colorShiftColor = greenCrossbowItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.56;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Reload";
	stateTimeoutValue[2]            = 0.14;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateSound[2]					= BowFireSound;

	stateName[3] = "Reload";
	stateSequence[3]                = "Reload";
	stateTimeoutValue[3]            = 0.56;
	stateTransitionOnTimeout[3]     = "Ready";
};

function greenCrossbowImage::onFire(%this,%obj,%slot)
{
	%projectile = %this.projectile;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			scale = "1.25 1.25 1.25";
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}