datablock AudioProfile(weaponSwitch3Sound)
{
   filename    = "./sounds/weaponSwitch3.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("redRevolver",   '<bitmap:add-ons/Weapon_OldSchool/icons/ci_Revolver> %1',    '%2 <bitmap:add-ons/Weapon_OldSchool/icons/ci_Revolver> %1',0.05,1);
datablock ProjectileData(redRevolverProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 45;
   directDamageType    = $DamageType::redRevolver;
   radiusDamageType    = $DamageType::redRevolver;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 200;
   verticalImpulse	  = 400;
   explosion           = gunExplosion;
   particleEmitter     = redTrailEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 0.5;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Revolver Bullet";
};

//////////
// item //
//////////
if($Pref::Server::OldSchoolWeapons::ColorfulColors)
	%color = "0.9 0.1 0.1 1.000";
else
	%color = "0.750 0.750 0.750 1.000";

datablock ItemData(redRevolverItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/revolver.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Revolver";
	iconName = "./icons/icon_Revolver";
	doColorShift = true;
	colorShiftColor = %color;

	 // Dynamic properties defined by the scripts
	image = redRevolverImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(redRevolverImage)
{
   // Basic Item properties
   shapeFile = "./models/revolver.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = redRevolverProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = redRevolverItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] 			= "Activate";
	stateTransitionOnTimeout[0] 	= "Ready";
	stateTimeoutValue[0] 		= 0.42;
	stateSequence[0] 		= "Activate";
   	stateSound[0]			= weaponSwitch3Sound;

	stateName[1] 			= "Ready";
	stateSequence[1] 		= "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] 			= "Fire";
	stateSequence[2] 		= "Fire";
	stateTransitionOnTimeout[2] 	= "Smoke";
   	stateWaitForTimeout[2] 		= true;
	stateTimeoutValue[2] 		= 0.21;
	stateFire[2] 			= true;
	stateAllowImageChange[2] 	= false;
	stateScript[2] 			= "onFire";
	stateSound[2] 			= gunShot1Sound;
   	stateEmitter[2]					= gunFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   	stateName[3] 			= "Smoke";
	stateEmitter[3]					= gunSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.07;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4] 			= "Reload";
	stateAllowImageChange[4] 	= false;
	stateTransitionOnTriggerUp[4] 	= "Ready";
	stateSequence[4] 		= "ready";
};

function redRevolverImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2, shiftaway);

	%projectile = redRevolverProjectile;
	%spread = 0.0002;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	
	%obj.setVelocity(VectorAdd(%obj.getVelocity(), VectorScale(%obj.client.player.getEyeVector(),"-1")));
}
